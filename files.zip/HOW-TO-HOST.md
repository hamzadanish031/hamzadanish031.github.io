# Hamza Portfolio — Upload & Hosting Guide

## What's in this package
- **index.html** — the entire portfolio (self-contained: CSS, JavaScript, and the headshot are all embedded inside this one file). This is the only file you strictly need to host.
- **hamza-headshot.jpg** — the cropped headshot, provided separately in case he wants it for LinkedIn/resume. (It's already baked into index.html, so you do NOT need to upload it for the site to work.)

## Host it free on GitHub Pages (about 3 minutes)

1. Sign in to GitHub as **hamzadanish031**.
2. Click **New** (top-left, or the "+" menu → New repository).
3. Name the repo exactly: **hamzadanish031.github.io**
   (Using this exact name makes the site live at https://hamzadanish031.github.io — the cleanest possible URL. Any other name also works but gives a longer URL.)
4. Set it to **Public**. Do NOT add a README. Click **Create repository**.
5. On the new empty repo page, click **"uploading an existing file"** (or Add file → Upload files).
6. Drag in **index.html**. Scroll down, click **Commit changes**.
7. Go to **Settings → Pages** (left sidebar).
8. Under "Build and deployment", Source = **Deploy from a branch**. Branch = **main**, folder = **/ (root)**. Click **Save**.
9. Wait ~1–2 minutes, refresh the Pages settings page. It will show:
   **"Your site is live at https://hamzadanish031.github.io"**

That URL is the portfolio. Share it, and add it to his resume and LinkedIn Featured section.

## To update the site later
Just re-upload a new index.html to the same repo (Add file → Upload files → commit, overwriting the old one). The live site updates within a minute or two.

## Notes
- The "Book a call" button and WhatsApp links are already wired to his real accounts.
- The certificate cards link to his existing `my-certificates` repo, so keep that repo public.
- The whole site works offline too — double-click index.html to preview it in any browser.
